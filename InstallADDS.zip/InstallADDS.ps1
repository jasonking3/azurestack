configuration InstallADDS
{
    param 
    ( 
        # [Parameter(Mandatory)] 
        # [string] $safemodePassword, 
        # [Parameter(Mandatory)] 
        # [string] $domainPassword
        [Parameter(Mandatory)]
        [PSCredential] $safemodeAdministratorCred,
        [Parameter(Mandatory)]
        [PSCredential] $domainCred
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration, xActiveDirectory
    
    # $secureSafemodePassword = ConvertTo-SecureString $safemodePassword -AsPlainText -Force
    # [PSCredential]$safemodeAdministratorCred = New-Object System.Management.Automation.PSCredential ("Administrator", $secureSafemodePassword)

    # $secureDomainPassword = ConvertTo-SecureString $domainPassword -AsPlainText -Force
    # [PSCredential]$domainCred = New-Object System.Management.Automation.PSCredential ("Administrator", $secureDomainPassword)

    node "localhost"
    {
        # Install Domain Services role
        WindowsFeature AD-Domain-Services
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }

        # Optional GUI tools            
        WindowsFeature RSAT-ADDS            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }            
       
        xADDomain FirstDC
        {
            DomainName = "ad.ciscops.net" 
            DomainAdministratorCredential = $domainCred 
            SafemodeAdministratorPassword = $safemodeAdministratorCred 
            # DnsDelegationCredential = $DNSDelegationCred 
            DependsOn = "[WindowsFeature]AD-Domain-Services" 
        }
    }
}
