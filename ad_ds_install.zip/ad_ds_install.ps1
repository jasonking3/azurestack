configuration ADInstall
{
    param 
    ( 
        # [Parameter(Mandatory)] 
        # [pscredential]$safemodeAdministratorCred, 
        # [Parameter(Mandatory)] 
        # [pscredential]$domainCred, 
        # [Parameter(Mandatory)] 
        # [pscredential]$DNSDelegationCred, 
        # [Parameter(Mandatory)] 
        # [pscredential]$NewADUserCred 
    )

    node "localhost"
    {
        # Install Domain Services role
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }

        # Optional GUI tools            
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }            
       
        # xADDomain FirstDS
        # {
        #     DomainName = "ad.ciscops.net" 
        #     DomainAdministratorCredential = $domainCred 
        #     SafemodeAdministratorPassword = $safemodeAdministratorCred 
        #     # DnsDelegationCredential = $DNSDelegationCred 
        #     DependsOn = "[WindowsFeature]ADDSInstall" 
        # }
    }
}