$ConfigData = @{
    AllNodes = @(
        @{ NodeName="localhost"; PSDscAllowPlainTextPassword = $true }
)}

configuration ADInstall
{
    param 
    ( 
        [Parameter(Mandatory)] 
        [string[]] $safemodePassword, 
        [Parameter(Mandatory)] 
        [string[]] $domainPassword
        # [PSCredential] $domainCred,
        # [PSCredential] $safemodeAdministratorCred
        # [Parameter(Mandatory)] 
        # [pscredential]$DNSDelegationCred, 
        # [Parameter(Mandatory)] 
        # [pscredential]$NewADUserCred 
    )

    Import-DscResource -ModuleName xActiveDirectory
    
    $secureSafemodePassword = ConvertTo-SecureString $safemodePassword -AsPlainText -Force
    [PSCredential]$safemodeAdministratorCred = New-Object System.Management.Automation.PSCredential ("Administrator", $secureSafemodePassword)

    $secureDomainPassword = ConvertTo-SecureString $domainPassword -AsPlainText -Force
    [PSCredential]$domainCred = New-Object System.Management.Automation.PSCredential ("Administrator", $secureDomainPassword)

    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }            

        # Install Domain Services role
        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }

        # Optional GUI tools            
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }            
       
        xADDomain FirstDS
        {
            DomainName = "ad.ciscops.net" 
            DomainAdministratorCredential = $domainCred 
            SafemodeAdministratorPassword = $safemodeAdministratorCred 
            # DnsDelegationCredential = $DNSDelegationCred 
            DependsOn = "[WindowsFeature]ADDSInstall" 
        }
    }
}

ADInstall -ConfigurationData $ConfigData